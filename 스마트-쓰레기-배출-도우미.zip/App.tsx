import React, { useState, useEffect } from 'react';
import { DisposalPoint, DisposalStatus } from './types';
import { DisposalPointsSheet } from './components/DisposalPointsSheet';
import { MapView } from './components/Map';
import { useGeolocation } from './hooks/useGeolocation';
import { useTruckLocation } from './hooks/useTruckLocation';
import { MainMenu } from './components/MainMenu';
import { MessageView } from './components/MessageView';
import { AnnouncementView } from './components/AnnouncementView';
import { MonitorIcon, SmartphoneIcon } from './components/Icons';

const INITIAL_DISPOSAL_POINTS: DisposalPoint[] = [
    // 도봉구
    { id: '1', name: '도봉구청', location: { lat: 37.6687, lng: 127.0471 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '2', name: '창동역 1번 출구', location: { lat: 37.654, lng: 127.047 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '7', name: '방학역', location: { lat: 37.6669, lng: 127.0438 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '8', name: '쌍문역', location: { lat: 37.6486, lng: 127.0347 }, disposalStatus: { general: false, recyclable: false, food: false } },
    // 노원구
    { id: '3', name: '노원역 롯데백화점', location: { lat: 37.6559, lng: 127.0624 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '4', name: '서울과학기술대학교', location: { lat: 37.6318, lng: 127.0775 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '9', name: '화랑대역', location: { lat: 37.6206, lng: 127.0823 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '10', name: '태릉입구역', location: { lat: 37.6174, lng: 127.0754 }, disposalStatus: { general: false, recyclable: false, food: false } },
    // 성북구
    { id: '5', name: '성신여대입구역', location: { lat: 37.5928, lng: 127.0169 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '6', name: '고려대학교', location: { lat: 37.5895, lng: 127.0323 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '11', name: '한성대입구역', location: { lat: 37.5885, lng: 127.0062 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '12', name: '안암역', location: { lat: 37.5861, lng: 127.0294 }, disposalStatus: { general: false, recyclable: false, food: false } },
    // 강북구
    { id: '13', name: '강북구청', location: { lat: 37.6398, lng: 127.0255 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '14', name: '수유역', location: { lat: 37.6387, lng: 127.0258 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '15', name: '미아역', location: { lat: 37.6267, lng: 127.0261 }, disposalStatus: { general: false, recyclable: false, food: false } },
    { id: '16', name: '미아사거리역', location: { lat: 37.6116, lng: 127.0302 }, disposalStatus: { general: false, recyclable: false, food: false } },
];

const TRUCK_ROUTE = INITIAL_DISPOSAL_POINTS.map(p => p.location);
const MAP_BOUNDS = {
    minLat: 37.57,
    maxLat: 37.68,
    minLng: 126.99,
    maxLng: 127.09,
};

type View = 'main' | 'map' | 'message' | 'announcement';
type NavDirection = 'in-right' | 'in-left' | 'in-up' | null;


const App: React.FC = () => {
    const [disposalPoints, setDisposalPoints] = useState<DisposalPoint[]>(INITIAL_DISPOSAL_POINTS);
    const [selectedPointId, setSelectedPointId] = useState<string | null>(null);
    const [pan, setPan] = useState({ x: 0, y: 0 });
    const [zoom, setZoom] = useState(1);
    const [view, setView] = useState<View>('main');
    const [navDirection, setNavDirection] = useState<NavDirection>(null);
    const [isDesktopView, setIsDesktopView] = useState<boolean>(() => JSON.parse(localStorage.getItem('isDesktopView') || 'false'));
    const [isMessagePopupOpen, setIsMessagePopupOpen] = useState(false);

    const userLocation = useGeolocation();
    const truckLocation = useTruckLocation(TRUCK_ROUTE);

    useEffect(() => {
        localStorage.setItem('isDesktopView', JSON.stringify(isDesktopView));
        setNavDirection(null); // Reset animation direction on view mode change
    }, [isDesktopView]);

    const handleToggleStatus = (id: string, wasteType: keyof DisposalStatus) => {
        setDisposalPoints(prevPoints =>
            prevPoints.map(p =>
                p.id === id
                ? { ...p, disposalStatus: { ...p.disposalStatus, [wasteType]: !p.disposalStatus[wasteType] } }
                : p
            )
        );
    };

    const handleResetPoints = () => {
        setDisposalPoints(INITIAL_DISPOSAL_POINTS.map(p => ({
            ...p,
            disposalStatus: { general: false, recyclable: false, food: false }
        })));
        setSelectedPointId(null);
    };

    const handleResetView = () => {
        setPan({ x: 0, y: 0 });
        setZoom(1);
    };
    
    const navigate = (target: View, direction: NavDirection) => {
        if (!isDesktopView) {
            setNavDirection(direction);
        }
        setView(target);
    };

    const handleNavigate = (target: View) => {
        if (isDesktopView && target === 'message') {
            setIsMessagePopupOpen(true);
        } else {
            const direction = target === 'message' ? 'in-up' : 'in-right';
            navigate(target, direction);
        }
    };
    
    const toggleViewMode = () => {
        const nextIsDesktopView = !isDesktopView;

        if (nextIsDesktopView && view === 'message') {
            setView('main');
            setIsMessagePopupOpen(true);
        }
        
        setIsDesktopView(nextIsDesktopView);
    };

    let animationClass = '';
    if (!isDesktopView && navDirection) {
        switch (navDirection) {
            case 'in-right': animationClass = 'animate-slide-in-right'; break;
            case 'in-left': animationClass = 'animate-slide-in-left'; break;
            case 'in-up': animationClass = 'animate-slide-up'; break;
        }
    }
    
    const renderView = () => {
        const viewProps = {
            className: `w-full h-full absolute top-0 left-0 ${animationClass}`,
        };

        switch (view) {
            case 'main':
                return (
                    <div key="main" {...viewProps}>
                        <MainMenu onNavigate={handleNavigate} />
                    </div>
                );
            case 'announcement':
                 return (
                    <div key="announcement" {...viewProps}>
                        <AnnouncementView onGoBack={() => navigate('main', 'in-left')} />
                    </div>
                );
            case 'map':
                if (isDesktopView) {
                     return (
                        <div className="flex w-full h-full">
                            <div className="w-3/4 h-full">
                                <MapView
                                    disposalPoints={disposalPoints}
                                    truckLocation={truckLocation}
                                    userLocation={userLocation.data}
                                    mapBounds={MAP_BOUNDS}
                                    pan={pan}
                                    setPan={setPan}
                                    zoom={zoom}
                                    setZoom={setZoom}
                                    onResetView={handleResetView}
                                    onPointSelect={setSelectedPointId}
                                />
                            </div>
                            <div className="w-1/4 h-full border-l border-green-200 dark:border-green-700">
                                <DisposalPointsSheet
                                    points={disposalPoints}
                                    onToggleStatus={handleToggleStatus}
                                    onReset={handleResetPoints}
                                    selectedPointId={selectedPointId}
                                    onPointSelect={setSelectedPointId}
                                    onDeselect={() => setSelectedPointId(null)}
                                    onGoBackToMain={() => navigate('main', 'in-left')}
                                    isDesktop={true}
                                />
                            </div>
                        </div>
                    );
                }
                return (
                     <div key="map" {...viewProps}>
                        <MapView
                            disposalPoints={disposalPoints}
                            truckLocation={truckLocation}
                            userLocation={userLocation.data}
                            mapBounds={MAP_BOUNDS}
                            pan={pan}
                            setPan={setPan}
                            zoom={zoom}
                            setZoom={setZoom}
                            onResetView={handleResetView}
                            onPointSelect={setSelectedPointId}
                        />
                        <div className="absolute bottom-0 left-0 right-0 h-1/2">
                            <DisposalPointsSheet
                                points={disposalPoints}
                                onToggleStatus={handleToggleStatus}
                                onReset={handleResetPoints}
                                selectedPointId={selectedPointId}
                                onPointSelect={setSelectedPointId}
                                onDeselect={() => setSelectedPointId(null)}
                                onGoBackToMain={() => navigate('main', 'in-left')}
                                isDesktop={false}
                            />
                        </div>
                    </div>
                );
            case 'message':
                 if (!isDesktopView) {
                    return (
                        <div key="message" {...viewProps}>
                            <MessageView onGoBack={() => navigate('main', 'in-left')} />
                        </div>
                    );
                }
                return null; // Desktop message is a popup, not a view
            default:
                return (
                     <div key="main" {...viewProps}>
                        <MainMenu onNavigate={handleNavigate} />
                    </div>
                );
        }
    }


    return (
        <div className={`h-screen w-screen flex flex-col font-sans bg-green-50 dark:bg-green-950 ${isDesktopView ? '' : 'items-center'}`}>
            <div className={`w-full h-full flex flex-col ${isDesktopView ? 'max-w-screen-xl mx-auto' : 'max-w-md'}`}>
                <header className="p-4 bg-green-100/80 dark:bg-green-900/80 backdrop-blur-sm shadow-md z-10 flex-shrink-0 flex items-center justify-end relative">
                    <h1 className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-2xl font-bold text-green-800 dark:text-green-100 whitespace-nowrap">
                        스마트 쓰레기 배출 도우미
                    </h1>
                    <button 
                        onClick={toggleViewMode} 
                        className="p-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                        aria-label={isDesktopView ? "모바일 뷰로 전환" : "데스크톱 뷰로 전환"}
                        title={isDesktopView ? "모바일 뷰로 전환" : "데스크톱 뷰로 전환"}
                    >
                        {isDesktopView 
                            ? <SmartphoneIcon className="w-6 h-6 text-green-700 dark:text-green-300"/> 
                            : <MonitorIcon className="w-6 h-6 text-green-700 dark:text-green-300" />}
                    </button>
                </header>

                <main className="flex-grow relative overflow-hidden">
                    {renderView()}
                </main>

                 {isDesktopView && isMessagePopupOpen && (
                    <div 
                        className="fixed inset-0 bg-black/50 z-30 flex justify-center items-end"
                        onClick={() => setIsMessagePopupOpen(false)}
                    >
                        <div 
                            className="w-full max-w-2xl h-[70vh] bg-green-50 dark:bg-green-900 rounded-t-2xl shadow-2xl flex flex-col animate-slide-up"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <MessageView onGoBack={() => setIsMessagePopupOpen(false)} isPopup={true} />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

export default App;