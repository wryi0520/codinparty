import React, { useState, useRef, useEffect } from 'react';
import { ArrowLeftIcon, XIcon } from './Icons';

interface MessageViewProps {
    onGoBack: () => void;
    isPopup?: boolean;
}

interface SentMessage {
    text: string;
    timestamp: Date;
}

export const MessageView: React.FC<MessageViewProps> = ({ onGoBack, isPopup }) => {
    const [message, setMessage] = useState('');
    const [history, setHistory] = useState<SentMessage[]>([]);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [history]);

    const handleSend = () => {
        if (message.trim() === '') {
            alert('메세지를 입력해주세요.');
            return;
        }
        
        const newMessage: SentMessage = {
            text: message,
            timestamp: new Date(),
        };

        setHistory(prevHistory => [...prevHistory, newMessage]);
        alert(`메세지: "${message}"\n\n성공적으로 전송되었습니다.`);
        setMessage('');
    };

    return (
        <div className="bg-green-100/50 dark:bg-green-900/50 flex flex-col h-full relative">
            <div className="p-4 border-b border-green-200 dark:border-green-700 flex items-center flex-shrink-0">
                {!isPopup && (
                    <button
                        onClick={onGoBack}
                        className="mr-3 p-2 -ml-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                        aria-label="메인으로 돌아가기"
                    >
                        <ArrowLeftIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
                    </button>
                )}
                <h2 className={`text-lg font-bold text-green-900 dark:text-green-100 ${isPopup ? 'text-center w-full' : 'truncate'}`}>메세지 기록</h2>
                 {isPopup && (
                    <button 
                        onClick={onGoBack}
                        className="absolute top-3 right-3 p-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                        aria-label="닫기"
                    >
                        <XIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
                    </button>
                )}
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-4">
                {history.length === 0 ? (
                    <div className="flex justify-center items-center h-full">
                        <p className="text-gray-500 dark:text-gray-400">전송된 메세지가 없습니다.</p>
                    </div>
                ) : (
                    history.map((msg, index) => (
                        <div key={index} className="flex justify-end">
                            <div className="bg-green-200 dark:bg-green-700 p-3 rounded-xl max-w-[80%]">
                                <p className="text-sm text-green-900 dark:text-green-100" style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                                    {msg.text}
                                </p>
                                <p className="text-xs text-right text-green-600 dark:text-green-400 mt-1">
                                    {msg.timestamp.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
                                </p>
                            </div>
                        </div>
                    ))
                )}
                <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-green-200 dark:border-green-700 flex-shrink-0 bg-green-100/50 dark:bg-green-900/50">
                <div className="flex items-start space-x-2">
                    <textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="수거 기사님께 전달할 메세지를 입력하세요..."
                        className="flex-grow p-2 bg-white dark:bg-green-800 border border-green-300 dark:border-green-700 rounded-lg text-green-900 dark:text-green-100 focus:ring-2 focus:ring-green-500 focus:outline-none resize-none"
                        aria-label="Message input"
                        rows={1}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSend();
                            }
                        }}
                        onInput={(e) => {
                             const target = e.target as HTMLTextAreaElement;
                             target.style.height = 'auto';
                             target.style.height = `${Math.min(target.scrollHeight, 120)}px`;
                        }}
                    />
                    <button
                        onClick={handleSend}
                        className="self-end px-4 py-2 bg-green-600 text-white font-bold rounded-lg shadow-md hover:bg-green-700 active:bg-green-800 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-green-100 dark:focus:ring-offset-green-900 focus:ring-green-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
                        disabled={!message.trim()}
                    >
                        전송
                    </button>
                </div>
            </div>
        </div>
    );
};