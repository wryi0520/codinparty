import React, { useState, useEffect } from 'react';

const WEATHERS = [
    { icon: '☀️', desc: '맑음' },
    { icon: '☁️', desc: '흐림' },
    { icon: '🌦️', desc: '가끔 비' },
    { icon: '🌧️', desc: '비' },
];

const weatherData = WEATHERS[Math.floor(Math.random() * WEATHERS.length)];

export const DateTimeWeather: React.FC = () => {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const formattedDate = currentTime.toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long',
    });

    const formattedTime = currentTime.toLocaleTimeString('ko-KR', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
    });

    return (
        <div className="text-center p-4 bg-green-100 dark:bg-green-800 rounded-lg shadow-inner">
            <div className="text-4xl font-bold text-green-800 dark:text-green-100 mb-2">
                {formattedTime}
            </div>
            <div className="text-md text-green-700 dark:text-green-300 mb-3">
                {formattedDate}
            </div>
            <div className="text-lg text-green-700 dark:text-green-300 flex items-center justify-center">
                <span className="text-2xl mr-2">{weatherData.icon}</span>
                <span>서울, {weatherData.desc} 24°C</span>
            </div>
        </div>
    );
};
