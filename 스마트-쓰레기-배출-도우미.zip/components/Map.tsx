import React, { useRef, useState } from 'react';
import { DisposalPoint, Coordinates } from '../types';
import { MapPinIcon, TruckIcon, RefreshIcon } from './Icons';

interface MapProps {
    disposalPoints: DisposalPoint[];
    truckLocation: Coordinates;
    userLocation: Coordinates | null;
    mapBounds: {
        minLat: number;
        maxLat: number;
        minLng: number;
        maxLng: number;
    };
    pan: { x: number; y: number };
    setPan: React.Dispatch<React.SetStateAction<{ x: number; y: number }>>;
    zoom: number;
    setZoom: React.Dispatch<React.SetStateAction<number>>;
    onResetView: () => void;
    onPointSelect: (id: string) => void;
}

const translateCoordsToPercent = (
    coords: Coordinates,
    bounds: MapProps['mapBounds']
) => {
    const latPercent = ((coords.lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100;
    const lngPercent = ((coords.lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
    return {
        top: `${100 - latPercent}%`,
        left: `${lngPercent}%`,
    };
};

const getPinColor = (status: DisposalPoint['disposalStatus']) => {
    const { general, recyclable, food } = status;
    const completedTasks = (general ? 1 : 0) + (recyclable ? 1 : 0) + (food ? 1 : 0);

    switch (completedTasks) {
        case 0:
            return 'text-green-500'; // 0개 완료
        case 1:
            return 'text-blue-500'; // 1개 완료
        case 2:
            return 'text-yellow-500'; // 2개 완료
        case 3:
        default:
            return 'text-red-500'; // 3개 완료
    }
};

export const MapView: React.FC<MapProps> = ({
    disposalPoints,
    truckLocation,
    userLocation,
    mapBounds,
    pan,
    setPan,
    zoom,
    setZoom,
    onResetView,
    onPointSelect,
}) => {
    const mapRef = useRef<HTMLDivElement>(null);
    const [isPanning, setIsPanning] = useState(false);
    const [startPanPoint, setStartPanPoint] = useState({ x: 0, y: 0 });

    const getPointerCoords = (e: React.MouseEvent | React.TouchEvent) => {
        if ('touches' in e && e.touches[0]) {
            return { x: e.touches[0].clientX, y: e.touches[0].clientY };
        }
        return { x: (e as React.MouseEvent).clientX, y: (e as React.MouseEvent).clientY };
    };

    const handlePanStart = (e: React.MouseEvent | React.TouchEvent) => {
        e.preventDefault();
        setIsPanning(true);
        const pointer = getPointerCoords(e);
        setStartPanPoint({
            x: pointer.x - pan.x,
            y: pointer.y - pan.y,
        });
    };

    const handlePanMove = (e: React.MouseEvent | React.TouchEvent) => {
        if (!isPanning) return;
        e.preventDefault();
        const pointer = getPointerCoords(e);
        setPan({
            x: pointer.x - startPanPoint.x,
            y: pointer.y - startPanPoint.y,
        });
    };

    const handlePanEnd = () => {
        setIsPanning(false);
    };

    const handleZoom = (e: React.WheelEvent) => {
        e.preventDefault();
        if (!mapRef.current) return;

        const zoomFactor = 1.1;
        const newZoom = e.deltaY < 0 ? zoom * zoomFactor : zoom / zoomFactor;
        const clampedZoom = Math.max(0.5, Math.min(newZoom, 4));

        const mapRect = mapRef.current.getBoundingClientRect();
        const mouseX = e.clientX - mapRect.left;
        const mouseY = e.clientY - mapRect.top;
        
        const newPanX = mouseX - ((mouseX - pan.x) * (clampedZoom / zoom));
        const newPanY = mouseY - ((mouseY - pan.y) * (clampedZoom / zoom));

        setZoom(clampedZoom);
        setPan({ x: newPanX, y: newPanY });
    };


    return (
        <div
            ref={mapRef}
            className="relative w-full h-full bg-green-200 dark:bg-green-800 overflow-hidden cursor-grab active:cursor-grabbing touch-none"
            onMouseDown={handlePanStart}
            onMouseMove={handlePanMove}
            onMouseUp={handlePanEnd}
            onMouseLeave={handlePanEnd}
            onTouchStart={handlePanStart}
            onTouchMove={handlePanMove}
            onTouchEnd={handlePanEnd}
            onWheel={handleZoom}
        >
            <button
                onClick={onResetView}
                className="absolute top-4 right-4 bg-green-50/80 dark:bg-green-950/80 backdrop-blur-sm p-2 rounded-full shadow-lg z-20 transition-transform hover:scale-110 active:scale-95"
                aria-label="Reset view"
                title="시점 초기화"
            >
                <RefreshIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
            </button>
            <div
                className="absolute top-0 left-0 w-full h-full"
                 style={{
                    transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                    transformOrigin: '0 0',
                }}
            >
                {disposalPoints.map((point) => {
                    const pos = translateCoordsToPercent(point.location, mapBounds);
                    const pinColor = getPinColor(point.disposalStatus);
                    return (
                        <div
                            key={point.id}
                            className="absolute transform -translate-x-1/2 -translate-y-full cursor-pointer"
                            style={{ top: pos.top, left: pos.left, transition: 'top 0.5s, left 0.5s' }}
                            onClick={() => onPointSelect(point.id)}
                        >
                            <MapPinIcon className={`w-8 h-8 ${pinColor}`} />
                            <span className="absolute top-full left-1/2 -translate-x-1/2 mt-1 text-xs bg-green-50/80 dark:bg-green-950/80 text-green-800 dark:text-green-200 px-1.5 py-0.5 rounded-md whitespace-nowrap">{point.name}</span>
                        </div>
                    );
                })}

                {userLocation && (
                    <div
                        className="absolute transform -translate-x-1/2 -translate-y-1/2"
                        style={{ ...translateCoordsToPercent(userLocation, mapBounds) }}
                    >
                        <div className="relative w-5 h-5 flex items-center justify-center">
                            <div className="absolute w-full h-full rounded-full bg-blue-500/50 animate-pulse"></div>
                            <div className="w-3 h-3 rounded-full bg-blue-500 border-2 border-white dark:border-green-800"></div>
                        </div>
                    </div>
                )}

                {truckLocation && (
                    <div
                        className="absolute transform -translate-x-1/2 -translate-y-1/2"
                        style={{ ...translateCoordsToPercent(truckLocation, mapBounds), transition: 'top 0.1s linear, left 0.1s linear' }}
                    >
                        <TruckIcon className="w-10 h-10 text-gray-900 dark:text-gray-100 bg-green-50/50 dark:bg-green-950/50 p-1 rounded-full shadow-lg" />
                    </div>
                )}
            </div>
        </div>
    );
};