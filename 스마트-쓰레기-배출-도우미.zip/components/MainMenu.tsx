import React from 'react';
import { MapIcon, MessageSquareIcon, MegaphoneIcon } from './Icons';
import { DateTimeWeather } from './DateTimeWeather';

interface MainMenuProps {
    onNavigate: (target: 'map' | 'message' | 'announcement') => void;
}

const MenuItem: React.FC<{
    icon: React.ElementType;
    label: string;
    description: string;
    onClick: () => void;
}> = ({ icon: Icon, label, description, onClick }) => (
    <button
        onClick={onClick}
        className="w-full flex items-center p-4 bg-green-100 dark:bg-green-800/50 rounded-xl shadow-md hover:bg-green-200 dark:hover:bg-green-800 transition-all transform hover:scale-105"
    >
        <div className="p-3 bg-green-500 rounded-lg mr-4">
            <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
            <h3 className="text-lg font-bold text-green-900 dark:text-green-100 text-left">{label}</h3>
            <p className="text-sm text-green-700 dark:text-green-300 text-left">{description}</p>
        </div>
    </button>
);

export const MainMenu: React.FC<MainMenuProps> = ({ onNavigate }) => {
    return (
        <div className="p-4 flex flex-col h-full bg-green-100/50 dark:bg-green-900/50">
            <div className="mb-4">
                <DateTimeWeather />
            </div>
            <div className="flex-grow space-y-4">
                <MenuItem
                    icon={MapIcon}
                    label="실시간 수거 현황"
                    description="지도에서 수거 차량 위치와 배출 현황을 확인하세요."
                    onClick={() => onNavigate('map')}
                />
                <MenuItem
                    icon={MessageSquareIcon}
                    label="기사님께 메세지 전송"
                    description="수거 관련 요청이나 감사 메세지를 전달하세요."
                    onClick={() => onNavigate('message')}
                />
                <MenuItem
                    icon={MegaphoneIcon}
                    label="지연 공지 확인"
                    description="교통, 차량 문제로 인한 수거 지연 정보를 확인하세요."
                    onClick={() => onNavigate('announcement')}
                />
            </div>
        </div>
    );
};
