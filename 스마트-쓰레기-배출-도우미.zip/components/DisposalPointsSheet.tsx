import React from 'react';
import { DisposalPoint, DisposalStatus } from '../types';
import { TrashBagIcon, RecycleIcon, FoodWasteIcon, ArrowLeftIcon } from './Icons';

interface DisposalPointsSheetProps {
    points: DisposalPoint[];
    onToggleStatus: (id: string, wasteType: keyof DisposalStatus) => void;
    onReset: () => void;
    selectedPointId: string | null;
    onPointSelect: (id: string) => void;
    onDeselect: () => void;
    onGoBackToMain: () => void;
    isDesktop?: boolean;
}

const WasteToggleButton: React.FC<{
    isDisposed: boolean;
    onClick: () => void;
    Icon: React.ElementType;
    label: string;
}> = ({ isDisposed, onClick, Icon, label }) => (
    <button onClick={onClick} className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors w-16 ${isDisposed ? 'bg-yellow-200 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200' : 'bg-green-200/60 dark:bg-green-700/60 hover:bg-green-200 dark:hover:bg-green-700'}`}>
        <Icon className="w-6 h-6" />
        <span className="text-xs font-medium">{label}</span>
    </button>
);

export const DisposalPointsSheet: React.FC<DisposalPointsSheetProps> = ({ points, onToggleStatus, onReset, selectedPointId, onPointSelect, onDeselect, onGoBackToMain, isDesktop }) => {
    const totalTasks = points.length * 3;
    const completedTasks = points.reduce((count, p) => {
        return count + (p.disposalStatus.general ? 1 : 0) + (p.disposalStatus.recyclable ? 1 : 0) + (p.disposalStatus.food ? 1 : 0);
    }, 0);
    const allCompleted = completedTasks === totalTasks;
    
    const selectedPoint = points.find(point => point.id === selectedPointId);

    const handleListButtonClick = (id: string, wasteType: keyof DisposalStatus) => {
        onToggleStatus(id, wasteType);
        onPointSelect(id);
    };

    const handleResetAll = () => {
        onReset();
    }
    
    if (selectedPoint) {
        const pointCompletedTasks = Object.values(selectedPoint.disposalStatus).filter(Boolean).length;
        
        return (
            <div className={`bg-green-50 dark:bg-green-900 flex flex-col h-full shadow-2xl ${!isDesktop ? 'rounded-t-2xl' : ''}`}>
                <div className="p-4 border-b border-green-200 dark:border-green-700 flex items-center flex-shrink-0">
                    <button
                        onClick={onDeselect}
                        className="mr-3 p-2 -ml-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                        aria-label="뒤로가기"
                    >
                        <ArrowLeftIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
                    </button>
                    <div className="flex-grow">
                      <h2 className="text-lg font-bold text-green-900 dark:text-green-100 truncate">{selectedPoint.name}</h2>
                    </div>
                    <span className="text-sm font-semibold text-green-700 dark:text-green-400 flex-shrink-0 ml-2">{pointCompletedTasks} / 3 완료</span>
                </div>
                <div className="flex-1 overflow-y-auto p-4 flex items-center justify-center">
                    <div className="flex justify-around items-center w-full max-w-xs space-x-4">
                        <WasteToggleButton
                            isDisposed={selectedPoint.disposalStatus.general}
                            onClick={() => onToggleStatus(selectedPoint.id, 'general')}
                            Icon={TrashBagIcon}
                            label="일반"
                        />
                        <WasteToggleButton
                            isDisposed={selectedPoint.disposalStatus.recyclable}
                            onClick={() => onToggleStatus(selectedPoint.id, 'recyclable')}
                            Icon={RecycleIcon}
                            label="재활용"
                        />
                        <WasteToggleButton
                            isDisposed={selectedPoint.disposalStatus.food}
                            onClick={() => onToggleStatus(selectedPoint.id, 'food')}
                            Icon={FoodWasteIcon}
                            label="음식물"
                        />
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className={`bg-green-50 dark:bg-green-900 flex flex-col h-full shadow-2xl ${!isDesktop ? 'rounded-t-2xl' : ''}`}>
            <div className="p-4 border-b border-green-200 dark:border-green-700 flex justify-between items-center flex-shrink-0">
                <div className="flex items-center flex-grow min-w-0">
                    <button
                        onClick={onGoBackToMain}
                        className="mr-3 p-2 -ml-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                        aria-label="메인으로 돌아가기"
                    >
                        <ArrowLeftIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
                    </button>
                    <h2 className="text-lg font-bold text-green-900 dark:text-green-100 truncate">배출 현황 ({completedTasks}/{totalTasks})</h2>
                </div>
                <button
                    onClick={handleResetAll}
                    className="text-sm text-blue-500 hover:text-blue-700 dark:hover:text-blue-400 font-medium transition-colors flex-shrink-0 ml-2"
                >
                    초기화
                </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
                <ul className="space-y-3">
                    {points.map(point => (
                        <li key={point.id} className="bg-green-100 dark:bg-green-800/50 p-3 rounded-xl">
                            <h3 className="font-bold text-green-900 dark:text-green-200 mb-2">{point.name}</h3>
                            <div className="flex justify-around items-center">
                                <WasteToggleButton
                                    isDisposed={point.disposalStatus.general}
                                    onClick={() => handleListButtonClick(point.id, 'general')}
                                    Icon={TrashBagIcon}
                                    label="일반"
                                />
                                <WasteToggleButton
                                    isDisposed={point.disposalStatus.recyclable}
                                    onClick={() => handleListButtonClick(point.id, 'recyclable')}
                                    Icon={RecycleIcon}
                                    label="재활용"
                                />
                                <WasteToggleButton
                                    isDisposed={point.disposalStatus.food}
                                    onClick={() => handleListButtonClick(point.id, 'food')}
                                    Icon={FoodWasteIcon}
                                    label="음식물"
                                />
                            </div>
                        </li>
                    ))}
                </ul>
                 {allCompleted && (
                    <div className="text-center p-6">
                        <p className="text-green-600 dark:text-green-400 font-semibold">모든 구역의 쓰레기 배출을 완료했습니다! 🎉</p>
                    </div>
                 )}
            </div>
        </div>
    );
};