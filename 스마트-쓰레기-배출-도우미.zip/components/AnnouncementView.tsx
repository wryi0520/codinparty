import React from 'react';
import { ArrowLeftIcon } from './Icons';

interface AnnouncementViewProps {
    onGoBack: () => void;
}

const announcements = [
    {
        id: 1,
        title: '차량 고장으로 인한 수거 지연',
        date: '2024-07-28',
        content: '금일 운행 예정이던 1호 수거 차량의 엔진 결함으로 인해, 도봉구 및 노원구 지역의 쓰레기 수거가 약 2시간 지연될 예정입니다. 긴급 수리 후 최대한 신속하게 작업을 재개하겠습니다. 주민 여러분의 양해 부탁드립니다.'
    },
    {
        id: 2,
        title: '교통 체증으로 인한 수거 시간 변경',
        date: '2024-07-27',
        content: '출근 시간대 교통 체증이 심각하여 성북구 지역의 수거 일정이 일부 조정되었습니다. 기존 오전 9시 수거 예정이던 지점들은 오전 11시 이후에 방문할 예정입니다. 이용에 참고하시기 바랍니다.'
    },
    {
        id: 3,
        title: '폭우 예보에 따른 안전 수칙 안내',
        date: '2024-07-25',
        content: '기상청의 폭우 예보에 따라, 금일 수거 작업 시 안전에 각별한 주의를 기울이고 있습니다. 배출된 쓰레기가 바람에 날아가거나 빗물에 휩쓸리지 않도록 단단히 고정해주시기 바랍니다.'
    }
];

export const AnnouncementView: React.FC<AnnouncementViewProps> = ({ onGoBack }) => {
    return (
        <div className="bg-green-100/50 dark:bg-green-900/50 flex flex-col h-full">
            <div className="p-4 border-b border-green-200 dark:border-green-700 flex items-center flex-shrink-0">
                <button
                    onClick={onGoBack}
                    className="mr-3 p-2 -ml-2 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
                    aria-label="메인으로 돌아가기"
                >
                    <ArrowLeftIcon className="w-5 h-5 text-green-700 dark:text-green-300" />
                </button>
                <h2 className="text-lg font-bold text-green-900 dark:text-green-100 truncate">지연 공지</h2>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
                <ul className="space-y-4">
                    {announcements.map(announcement => (
                        <li key={announcement.id} className="bg-green-50 dark:bg-green-800/50 p-4 rounded-xl shadow">
                            <h3 className="font-bold text-md text-green-900 dark:text-green-200">{announcement.title}</h3>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">{announcement.date}</p>
                            <p className="text-sm text-green-800 dark:text-green-300">{announcement.content}</p>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};