export interface Coordinates {
  lat: number;
  lng: number;
}

export interface DisposalStatus {
  general: boolean;
  recyclable: boolean;
  food: boolean;
}

export interface DisposalPoint {
  id: string;
  name: string;
  location: Coordinates;
  disposalStatus: DisposalStatus;
}
