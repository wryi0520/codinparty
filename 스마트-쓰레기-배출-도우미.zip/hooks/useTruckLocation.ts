import { useState, useEffect } from 'react';
import { Coordinates } from '../types';

const SIMULATION_SPEED = 50; // lower is faster
const MOVE_INCREMENT = 0.0001; // distance per tick

export const useTruckLocation = (route: Coordinates[]) => {
    const [truckLocation, setTruckLocation] = useState<Coordinates>(route[0]);
    const [routeIndex, setRouteIndex] = useState(0);

    useEffect(() => {
        if (!route || route.length === 0) return;

        const moveTruck = () => {
            setTruckLocation(currentLocation => {
                const target = route[routeIndex];
                if (!target) return currentLocation;

                const latDiff = target.lat - currentLocation.lat;
                const lngDiff = target.lng - currentLocation.lng;

                const distance = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);

                if (distance < MOVE_INCREMENT) {
                    setRouteIndex((prevIndex) => (prevIndex + 1) % route.length);
                    return target;
                }

                const newLat = currentLocation.lat + (latDiff / distance) * MOVE_INCREMENT;
                const newLng = currentLocation.lng + (lngDiff / distance) * MOVE_INCREMENT;

                return { lat: newLat, lng: newLng };
            });
        };

        const intervalId = setInterval(moveTruck, SIMULATION_SPEED);

        return () => clearInterval(intervalId);
    }, [route, routeIndex]);

    return truckLocation;
};