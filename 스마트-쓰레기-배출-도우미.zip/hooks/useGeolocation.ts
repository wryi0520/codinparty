import { useState, useEffect } from 'react';
import { Coordinates } from '../types';

interface GeolocationState {
    loading: boolean;
    error: GeolocationPositionError | null;
    data: Coordinates | null;
}

export const useGeolocation = () => {
    const [state, setState] = useState<GeolocationState>({
        loading: true,
        error: null,
        data: null,
    });

    useEffect(() => {
        const onSuccess = (position: GeolocationPosition) => {
            setState({
                loading: false,
                error: null,
                data: {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                },
            });
        };

        const onError = (error: GeolocationPositionError) => {
            setState({
                loading: false,
                error,
                data: null,
            });
        };

        if (!navigator.geolocation) {
            // Mock location if geolocation is not available
            console.warn("Geolocation not supported, using mock location.");
            setTimeout(() => { // Simulate async loading
                setState({
                    loading: false,
                    error: null,
                    data: { lat: 37.555, lng: 126.975 },
                });
            }, 1000);
            return;
        }

        const watcher = navigator.geolocation.watchPosition(onSuccess, onError);

        return () => navigator.geolocation.clearWatch(watcher);
    }, []);

    return state;
};